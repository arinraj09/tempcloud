// ── Prevent duplicate instances ───────────────────────────────────────────────
if (window.__snDispatcherContentScriptLoaded) {
    throw new Error('Aryan\'s Dispatcher: content script already loaded, skipping re-init');
}
window.__snDispatcherContentScriptLoaded = true;

// ── Only the TOP frame relays messages and manages the overlay ────────────────
// ServiceNow is heavily framed. chrome.tabs.sendMessage (with no frameId) delivers
// to EVERY frame. We only want the top frame to inject autoroute.js and forward
// messages — sub-frames don't have window.g_ck and the overlay lives in the top frame.
const IS_TOP_FRAME = (window === window.top);

// ── Relay page → popup ────────────────────────────────────────────────────────
if (IS_TOP_FRAME) {
    window.addEventListener('message', function(e) {
        if (!e.data) return;
        const t = e.data.type;

        if (t === 'DISPATCHER_STATUS' || t === 'DISPATCHER_ALREADY_RUNNING' || t === 'DISPATCHER_ERROR') {
            chrome.runtime.sendMessage(e.data);
            if (t === 'DISPATCHER_STATUS') forwardToOverlay(e.data);
        }

        // Pong reply from autoroute.js — forward to popup
        if (t === 'DISPATCHER_PONG') {
            chrome.runtime.sendMessage({ type: 'DISPATCHER_PONG' });
        }
    });
}

// ── overlayCmd: postMessage directly (no script injection) ───────────────────
// Content scripts share the window messaging bus with the MAIN world.
// window.top.postMessage from a content script IS received by MAIN-world listeners.
// This avoids CSP issues entirely — no inline <script> injection needed.
function overlayCmd(data) {
    window.top.postMessage({ type: 'OVERLAY_CMD', ...data }, '*');
}

function ts() {
    return new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function forwardToOverlay(msg) {
    switch (msg.event) {
        case 'started':
            overlayCmd({ action: 'setState', state: 'running' });
            overlayCmd({ action: 'addLog', time: ts(), msg: '🚀 AutoRoute started', color: '#4ade80' });
            break;
        case 'countdown':
            overlayCmd({ action: 'setCountdown', value: msg.value });
            break;
        case 'running':
            overlayCmd({ action: 'setCountdown', value: '...' });
            overlayCmd({ action: 'addLog', time: ts(), msg: '── Cycle started ──', color: '#475569' });
            break;
        case 'cycleComplete':
            overlayCmd({ action: 'updateStats', inc: msg.incRouted, chg: msg.chgRouted });
            overlayCmd({ action: 'addLog', time: ts(), msg: '── INC: ' + msg.incRouted + ' routed | CHG: ' + msg.chgRouted + ' routed ──', color: '#4ade80' });
            break;
        case 'log':
            overlayCmd({ action: 'addLog', time: ts(), msg: msg.message, color: msg.color || '#e2e8f0' });
            break;
        case 'paused':
            overlayCmd({ action: 'setState', state: 'paused' });
            overlayCmd({ action: 'addLog', time: ts(), msg: '⏸ Paused', color: '#fbbf24' });
            break;
        case 'resumed':
            overlayCmd({ action: 'setState', state: 'running' });
            overlayCmd({ action: 'addLog', time: ts(), msg: '▶ Resumed', color: '#4ade80' });
            break;
        case 'stopped':
            overlayCmd({ action: 'setState', state: 'stopped' });
            overlayCmd({ action: 'setCountdown', value: '—' });
            overlayCmd({ action: 'addLog', time: ts(), msg: '⏹ Stopped', color: '#f87171' });
            break;
    }
}

chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
    if (!msg) return;

    // ── Liveness ping from popup ──────────────────────────────────────────────
    if (msg.source === 'DISPATCHER_CS_PING') {
        sendResponse({ alive: true });
        return;
    }

    // ── Inject autoroute.js — top frame only ─────────────────────────────────
    // <script src="chrome-extension://..."> is NOT an inline script, so it is
    // NOT blocked by CSP. This is the safe way to inject into the MAIN world.
    if (msg.source === 'DISPATCHER_INJECT') {
        if (!IS_TOP_FRAME) { sendResponse({}); return; }
        const s = document.createElement('script');
        s.src = chrome.runtime.getURL('autoroute.js');
        document.head.appendChild(s);
        sendResponse({});
        return;
    }

    // ── Ping: check if autoroute.js is alive ─────────────────────────────────
    // Send a postMessage ping directly — autoroute.js listens for DISPATCHER_PING
    // type and will postMessage back a PONG. No inline script injection needed.
    if (msg.source === 'DISPATCHER_PING') {
        if (!IS_TOP_FRAME) { sendResponse({}); return; }
        window.postMessage({ type: 'DISPATCHER_PING' }, '*');
        sendResponse({});
        return;
    }

    // ── Forward popup commands to page world ─────────────────────────────────
    // KEY FIX: use window.postMessage directly instead of injecting a <script> tag.
    // Content scripts share the window messaging bus with MAIN world scripts,
    // so autoroute.js (running in MAIN world) WILL receive this postMessage.
    // Inline <script> injection is blocked by ServiceNow's CSP (no 'unsafe-inline').
    if (msg.source === 'DISPATCHER_POPUP' && msg.command !== '__overlay__') {
        if (!IS_TOP_FRAME) { sendResponse({}); return; }
        window.postMessage({ source: 'DISPATCHER_POPUP', command: msg.command }, '*');
        sendResponse({});
        return;
    }

    // ── Overlay commands from popup (log replay on pin) ───────────────────────
    if (msg.source === 'DISPATCHER_POPUP' && msg.command === '__overlay__' && msg.data) {
        if (!IS_TOP_FRAME) { sendResponse({}); return; }
        overlayCmd(msg.data);
        sendResponse({});
    }
});
