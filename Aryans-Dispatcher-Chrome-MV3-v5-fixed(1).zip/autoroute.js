(function () {
    // ── Prevent duplicate instances ───────────────────────────────────────────
    if (window.snAutoRouteRunning) {
        window.postMessage({ type: 'DISPATCHER_ALREADY_RUNNING' }, '*');
        return;
    }
    window.snAutoRouteRunning = true;

    var token = window.g_ck || document.querySelector('input[name="sysparm_ck"]')?.value || '';

    if (!token) {
        window.snAutoRouteRunning = false;
        window.postMessage({ type: 'DISPATCHER_ERROR', message: 'Not logged in to ServiceNow!' }, '*');
        return;
    }

    // ── Queries ───────────────────────────────────────────────────────────────
    // Fetch unassigned open incidents from source groups.
    // EXCLUDE: integration tickets already in GUHD_OFFLINE_L1 — never touch those.
    // Two blocks joined with NQ (OR):
    //   Block 1: Global_L1_Support + GetIT_Global_L1_Support — all channels
    //   Block 2: GUHD_OFFLINE_L1 — only NON-integration channels
    var incidentBaseQuery =
        'assignment_group.nameINGlobal_L1_Support%2CGetIT_Global_L1_Support%5EstateIN1%2C2%2C3%5Eassigned_toISEMPTY' +
        '%5ENQ' +
        'assignment_group.name%3DGUHD_OFFLINE_L1%5EstateIN1%2C2%2C3%5Eassigned_toISEMPTY%5Econtact_type%21%3Dintegration';

    var changeQuery       = 'assignment_group%3D4bc8def91b1f785030821f0f8b4bcb0c%5Estate%3D-5%5Eshort_descriptionLIKEFirewall%20Request';
    var changeTargetGroup = 'a5572c7ddbd730102dae55fbd396194b';

    // sys_id of GUHD_OFFLINE_L1 (routing target for integration channel fallback)
    var GUHD_OFFLINE_L1_ID = '2930353adb16c51026bc2e730596195e';

    var groupNames = {
        '27981cd81bd2dd509c1011718b4bcb2a': 'GUHD_OneERP_L1',
        '6c4927c11ba65c901649dc2c9b4bcb13': 'GUHD_SMARAGD_L1',
        'be47410edb4b0190574073e3f3961969': 'GUHD_MBSP_L1',
        '1a221a511b4e59509c1011718b4bcb37': '415_MBTI_UHD',
        '06eac0571b58701049d742609b4bcba1': '601_UHD_L1',
        '2cb3ab6dc3dcb6985a76d5fe05013189': 'Global_SD_UHD_L1',
        '2930353adb16c51026bc2e730596195e': 'GUHD_OFFLINE_L1'
    };

    function getTargetGroup(rec) {
        var sd      = (rec.short_description || '').toUpperCase();
        var plant   = rec['caller_id.u_plant_2'] || '';
        if (typeof plant === 'object') plant = plant.value || '';
        var channel = rec.contact_type || '';
        if (typeof channel === 'object') channel = channel.value || '';
        channel = channel.trim().toLowerCase();

        // Priority 1-5: keyword / plant rules (channel does not affect these)
        if (/BP1|BP01|BANF|GRC|BESTLLUNG|BESTELLUNG|ONEERP/.test(sd)) return '27981cd81bd2dd509c1011718b4bcb2a';
        if (sd.includes('SMARAGD'))                                     return '6c4927c11ba65c901649dc2c9b4bcb13';
        if (sd.includes('MBSP'))                                        return 'be47410edb4b0190574073e3f3961969';
        if (plant === 'a4cf3804dbb540501076366af4961968')               return '1a221a511b4e59509c1011718b4bcb37';
        if (plant === 'f8cf3804dbb540501076366af49619d0')               return '06eac0571b58701049d742609b4bcba1';

        // Priority 6 fallback:
        // Integration channel (from Global_L1_Support / GetIT_Global_L1_Support) → GUHD_OFFLINE_L1
        if (channel === 'integration') return GUHD_OFFLINE_L1_ID;

        // All other channels (blank, phone, self-service, email, walk-in…) → Global_SD_UHD_L1
        // Blank channel will be set to self-service by the patch below
        return '2cb3ab6dc3dcb6985a76d5fe05013189';
    }

    // ── Post status updates to extension popup ────────────────────────────────
    function postStatus(data) {
        window.postMessage({ type: 'DISPATCHER_STATUS', ...data }, '*');
    }

    // ── Route incidents ───────────────────────────────────────────────────────
    function routeIncidents(callback) {
        // Fetch ALL incidents from source groups — no channel filter, integration included
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '/api/now/table/incident?sysparm_query=' + incidentBaseQuery +
            '&sysparm_fields=sys_id,number,short_description,caller_id.u_plant_2,contact_type&sysparm_limit=1000', false);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('X-UserToken', token);
        xhr.send();
        var records = JSON.parse(xhr.responseText).result || [];

        if (records.length === 0) { callback(0, 0); return; }

        var success = 0, failed = 0, i = 0;
        function next() {
            if (i >= records.length) { callback(success, failed); return; }
            var rec = records[i]; i++;
            var tg  = getTargetGroup(rec);

            // Determine channel: if blank, set to self-service
            var currentChannel = rec.contact_type || '';
            if (typeof currentChannel === 'object') currentChannel = currentChannel.value || '';

            var patchBody = { assignment_group: tg, state: '1' };
            if (!currentChannel || currentChannel.trim() === '') {
                patchBody.contact_type = 'self-service';
            }

            var patch = new XMLHttpRequest();
            patch.open('PATCH', '/api/now/table/incident/' + rec.sys_id, true);
            patch.setRequestHeader('Content-Type', 'application/json');
            patch.setRequestHeader('Accept', 'application/json');
            patch.setRequestHeader('X-UserToken', token);
            patch.onreadystatechange = function () {
                if (patch.readyState !== 4) return;
                var channelNote = patchBody.contact_type ? ' [channel→self-service]' : '';
                if (patch.status === 200) {
                    success++;
                    postStatus({ event: 'log', message: '✅ ' + rec.number + ' → ' + groupNames[tg] + channelNote, color: '#4ade80' });
                } else {
                    failed++;
                    postStatus({ event: 'log', message: '❌ ' + rec.number + ' failed', color: '#f87171' });
                }
                next();
            };
            patch.send(JSON.stringify(patchBody));
        }
        next();
    }

    // ── Route changes ─────────────────────────────────────────────────────────
    function routeChanges(callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '/api/now/table/change_request?sysparm_query=' + changeQuery +
            '&sysparm_fields=sys_id,number,end_date&sysparm_limit=1000', false);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('X-UserToken', token);
        xhr.send();
        var records = JSON.parse(xhr.responseText).result || [];

        if (records.length === 0) { callback(0, 0, 0); return; }

        var success = 0, failed = 0, skipped = 0, i = 0;
        function next() {
            if (i >= records.length) { callback(success, failed, skipped); return; }
            var rec = records[i]; i++;
            if (!rec.end_date) { skipped++; next(); return; }
            var patch = new XMLHttpRequest();
            patch.open('PATCH', '/api/now/table/change_request/' + rec.sys_id, true);
            patch.setRequestHeader('Content-Type', 'application/json');
            patch.setRequestHeader('Accept', 'application/json');
            patch.setRequestHeader('X-UserToken', token);
            patch.onreadystatechange = function () {
                if (patch.readyState !== 4) return;
                if (patch.status === 200) {
                    success++;
                    postStatus({ event: 'log', message: '✅ ' + rec.number + ' → CHG routed', color: '#60a5fa' });
                } else {
                    failed++;
                    postStatus({ event: 'log', message: '❌ ' + rec.number + ' failed', color: '#f87171' });
                }
                next();
            };
            patch.send(JSON.stringify({ assignment_group: changeTargetGroup, requested_by_date: rec.end_date }));
        }
        next();
    }

    // ── Main cycle ────────────────────────────────────────────────────────────
    var INTERVAL_MS = 120000;
    var paused      = false;
    var countdownId = null;
    var remainingMs = 0;

    function startCountdown(onComplete) {
        remainingMs = INTERVAL_MS;
        clearInterval(countdownId);
        countdownId = setInterval(function () {
            if (paused) return;
            remainingMs -= 1000;
            var mins = Math.floor(remainingMs / 60000);
            var secs = Math.floor((remainingMs % 60000) / 1000);
            postStatus({ event: 'countdown', value: mins + ':' + (secs < 10 ? '0' : '') + secs });
            if (remainingMs <= 0) {
                clearInterval(countdownId);
                onComplete();
            }
        }, 1000);
    }

    function runCycle() {
        if (paused) { startCountdown(runCycle); return; }
        var now = new Date().toLocaleTimeString();
        postStatus({ event: 'running', time: now });
        routeIncidents(function (incS, incF) {
            routeChanges(function (chgS, chgF, chgSk) {
                postStatus({ event: 'cycleComplete', incRouted: incS, incFailed: incF, chgRouted: chgS, chgFailed: chgF, chgSkipped: chgSk, time: now });
                startCountdown(runCycle);
            });
        });
    }

    // ── Listen for popup commands and pings ───────────────────────────────────
    window.addEventListener('message', function (e) {
        if (!e.data) return;

        // Ping from content.js (sent via window.postMessage, no script injection).
        // Reply with a PONG so popup knows autoroute.js is still alive.
        if (e.data.type === 'DISPATCHER_PING') {
            window.postMessage({ type: 'DISPATCHER_PONG' }, '*');
            return;
        }

        if (e.data.source !== 'DISPATCHER_POPUP') return;
        if (e.data.command === 'pause')  { paused = true;  postStatus({ event: 'paused' }); }
        if (e.data.command === 'resume') { paused = false; postStatus({ event: 'resumed' }); }
        if (e.data.command === 'stop')   {
            clearInterval(countdownId);
            window.snAutoRouteRunning = false;
            postStatus({ event: 'stopped' });
        }
    });

    // ── Kick off ──────────────────────────────────────────────────────────────
    postStatus({ event: 'started' });
    runCycle();
})();
