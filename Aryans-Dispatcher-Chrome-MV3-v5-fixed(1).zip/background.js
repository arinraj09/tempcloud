// ── Background service worker ─────────────────────────────────────────────────
// On install/update, inject content.js into already-open SN tabs (top frame only).
// Sub-frames don't need content.js — injecting there caused "Not logged in" errors
// because each sub-frame would try to inject autoroute.js into itself.
chrome.runtime.onInstalled.addListener(async () => {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
        if (tab.url && (tab.url.includes('service-now.com') || tab.url.includes('mercedes-benz.com'))) {
            try {
                await chrome.scripting.executeScript({
                    target: { tabId: tab.id, frameIds: [0] },
                    files: ['content.js']
                });
            } catch (e) {
                // Tab may not be injectable (chrome:// pages etc.) — ignore
            }
        }
    }
});
