const INTERVAL_SECS = 120;

let activeTabId = null;
let logCount    = 0;
let isRunning   = false;
let isPaused    = false;
let allLogs     = [];
let pongTimeout = null;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const btnStart      = document.getElementById('btnStart');
const btnPause      = document.getElementById('btnPause');
const btnStop       = document.getElementById('btnStop');
const btnPin        = document.getElementById('btnPin');
const btnExport     = document.getElementById('btnExport');
const statusDot     = document.getElementById('statusDot');
const statusText    = document.getElementById('statusText');
const countdown     = document.getElementById('countdown');
const progressBar   = document.getElementById('progressBar');
const statInc       = document.getElementById('statInc');
const statChg       = document.getElementById('statChg');
const logBody       = document.getElementById('logBody');
const logCountEl    = document.getElementById('logCount');
const connBadge     = document.getElementById('connBadge');
const refreshBanner = document.getElementById('refreshBanner');
const btnReinject   = document.getElementById('btnReinject');

// ── Storage ───────────────────────────────────────────────────────────────────
async function saveState(patch) {
    try {
        const cur  = await chrome.storage.session.get('dispatcherState');
        const prev = (cur && cur.dispatcherState) ? cur.dispatcherState : {};
        await chrome.storage.session.set({ dispatcherState: { ...prev, ...patch } });
    } catch(e) {}
}
async function loadState() {
    try {
        const cur = await chrome.storage.session.get('dispatcherState');
        return (cur && cur.dispatcherState) ? cur.dispatcherState : {};
    } catch(e) { return {}; }
}

// ── UI helpers ────────────────────────────────────────────────────────────────
function addLog(msg, color) {
    const empty = logBody.querySelector('[data-placeholder="true"]');
    if (empty) empty.parentElement.remove();
    const now = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    allLogs.push({ time: now, msg, color: color || '#e2e8f0' });
    const line = document.createElement('div'); line.className = 'log-line';
    const ts = document.createElement('span'); ts.className = 'log-time'; ts.textContent = now;
    const ms = document.createElement('span'); ms.className = 'log-msg'; ms.style.color = color || '#e2e8f0'; ms.textContent = msg;
    line.appendChild(ts); line.appendChild(ms);
    logBody.appendChild(line);
    logBody.scrollTop = logBody.scrollHeight;
    while (logBody.children.length > 30) logBody.removeChild(logBody.firstChild);
    logCount++;
    logCountEl.textContent = logCount + ' event' + (logCount !== 1 ? 's' : '');
}

function setDot(state) { statusDot.className = 'status-dot ' + state; }
function setStatus(msg, color) { statusText.textContent = msg; statusText.style.color = color || '#64748b'; }
function setCountdown(val) {
    countdown.textContent = val;
    const parts = val.split(':');
    if (parts.length === 2) {
        const rem = parseInt(parts[0]) * 60 + parseInt(parts[1]);
        progressBar.style.width = ((INTERVAL_SECS - rem) / INTERVAL_SECS * 100) + '%';
        countdown.classList.toggle('urgent', rem <= 15);
    }
}
function applyRunningUI() {
    btnStart.disabled = true; btnPause.disabled = false; btnStop.disabled = false;
    setDot(isPaused ? 'paused' : 'running');
    btnPause.textContent = isPaused ? '▶ Resume' : '⏸ Pause';
}
function applyStoppedUI() {
    btnStart.disabled = false; btnPause.disabled = true; btnStop.disabled = true;
    setDot('stopped'); countdown.textContent = '—'; progressBar.style.width = '0%';
    btnPause.textContent = '⏸ Pause';
}
function showRefreshBanner(show) {
    refreshBanner.style.display = show ? 'flex' : 'none';
}

// ── Get SN tab ────────────────────────────────────────────────────────────────
async function getSnTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab  = tabs[0];
    if (tab && tab.url && (tab.url.includes('service-now.com') || tab.url.includes('mercedes-benz.com'))) return tab;
    const all = await chrome.tabs.query({});
    return all.find(t => t.url && (t.url.includes('service-now.com') || t.url.includes('mercedes-benz.com'))) || null;
}

// ── Ensure content script is alive in tab (MV3: may not be injected yet) ──────
async function ensureContentScript(tabId) {
    try {
        // Ping the TOP frame only (frameId: 0). content.js now calls sendResponse()
        // immediately, so this promise resolves in <50 ms when the script is present.
        await new Promise((resolve, reject) => {
            chrome.tabs.sendMessage(tabId, { source: 'DISPATCHER_CS_PING' }, { frameId: 0 }, (response) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(response);
            });
        });
    } catch (e) {
        // Content script missing in top frame — inject it now (top frame only).
        // We do NOT inject into allFrames: sub-frames don't need it and it caused
        // "Not logged in" errors when each sub-frame injected autoroute.js itself.
        await chrome.scripting.executeScript({
            target: { tabId: tabId, frameIds: [0] },
            files: ['content.js']
        });
        // Give it a moment to initialise
        await new Promise(r => setTimeout(r, 150));
    }
}


// ── Ping: check if autoroute.js is alive in the page ─────────────────────────
// Returns a promise that resolves true (alive) or false (dead/page refreshed)
function pingPage(tabId) {
    return new Promise(resolve => {
        let resolved = false;

        // We'll hear the pong via the normal onMessage listener below
        // Store the resolve so onMessage can call it
        window._pendingPingResolve = function(alive) {
            if (!resolved) { resolved = true; resolve(alive); }
        };

        // Send ping to content script → page world
        chrome.tabs.sendMessage(tabId, { source: 'DISPATCHER_PING' }).catch(() => {
            if (!resolved) { resolved = true; resolve(false); }
        });

        // Timeout — if no pong in 600ms, page script is dead
        setTimeout(() => {
            if (!resolved) { resolved = true; resolve(false); }
        }, 600);
    });
}

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg) {
    if (!msg || !msg.type) return;

    // Pong reply — autoroute.js is alive
    if (msg.type === 'DISPATCHER_PONG') {
        if (window._pendingPingResolve) {
            window._pendingPingResolve(true);
            window._pendingPingResolve = null;
        }
        return;
    }

    if (msg.type === 'DISPATCHER_ALREADY_RUNNING') {
        showRefreshBanner(false);
        isRunning = true; isPaused = false;
        applyRunningUI();
        setStatus('Already running in this tab!', '#fbbf24');
        addLog('⚠️ Already running', '#fbbf24');
        saveState({ isRunning: true, isPaused: false });
        return;
    }

    if (msg.type === 'DISPATCHER_ERROR') {
        setStatus('❌ ' + msg.message, '#f87171');
        addLog('❌ Error: ' + msg.message, '#f87171');
        isRunning = false; applyStoppedUI();
        saveState({ isRunning: false, isPaused: false });
        return;
    }

    if (msg.type !== 'DISPATCHER_STATUS') return;

    switch (msg.event) {
        case 'started':
            showRefreshBanner(false);
            isRunning = true; isPaused = false;
            applyRunningUI();
            setStatus('⚡ Running first cycle...', '#4ade80');
            addLog('🚀 AutoRoute started', '#4ade80');
            saveState({ isRunning: true, isPaused: false });
            break;
        case 'countdown': setCountdown(msg.value); break;
        case 'running':
            setStatus('⚡ Routing in progress...', '#38bdf8');
            addLog('── Cycle started ──', '#475569');
            countdown.textContent = '...'; progressBar.style.width = '100%';
            break;
        case 'cycleComplete':
            statInc.textContent = msg.incRouted; statChg.textContent = msg.chgRouted;
            setStatus('✅ Done at ' + msg.time, '#4ade80');
            addLog('── INC: ' + msg.incRouted + ' routed | CHG: ' + msg.chgRouted + ' routed ──', '#4ade80');
            saveState({ lastInc: msg.incRouted, lastChg: msg.chgRouted });
            break;
        case 'log': addLog(msg.message, msg.color); break;
        case 'paused':
            isPaused = true; setDot('paused');
            setStatus('⏸ Paused', '#fbbf24'); addLog('⏸ Paused by user', '#fbbf24');
            btnPause.textContent = '▶ Resume'; saveState({ isPaused: true });
            break;
        case 'resumed':
            isPaused = false; setDot('running');
            setStatus('▶ Resumed', '#4ade80'); addLog('▶ Resumed', '#4ade80');
            btnPause.textContent = '⏸ Pause'; saveState({ isPaused: false });
            break;
        case 'stopped':
            isRunning = false; isPaused = false;
            applyStoppedUI();
            setStatus('Stopped. Click Start to restart.', '#64748b');
            addLog('⏹ Stopped by user', '#f87171');
            saveState({ isRunning: false, isPaused: false });
            break;
    }
});

// ── Send command ──────────────────────────────────────────────────────────────
async function sendCommand(cmd) {
    if (!activeTabId) {
        const tab = await getSnTab();
        if (tab) activeTabId = tab.id;
    }
    if (!activeTabId) { setStatus('❌ No ServiceNow tab found!', '#f87171'); return; }
    try {
        await ensureContentScript(activeTabId);
        // frameId: 0 targets only the top frame — content.js there will forward to page world.
        // This avoids Chrome MV3 rejecting the promise when sub-frame listeners don't respond.
        await chrome.tabs.sendMessage(activeTabId, { source: 'DISPATCHER_POPUP', command: cmd }, { frameId: 0 });
    } catch(err) { setStatus('❌ Send failed: ' + err.message, '#f87171'); }
}

// ── Buttons ───────────────────────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
    btnStart.disabled = true;
    setStatus('Starting...', '#38bdf8');
    try {
        const tab = await getSnTab();
        if (!tab) {
            setStatus('❌ No ServiceNow tab found!', '#f87171');
            addLog('❌ No ServiceNow tab found', '#f87171');
            btnStart.disabled = false; return;
        }
        activeTabId = tab.id;
        await saveState({ activeTabId: tab.id });
        await ensureContentScript(activeTabId);
        addLog('📦 Using bundled script', '#38bdf8');
        await chrome.tabs.sendMessage(activeTabId, { source: 'DISPATCHER_INJECT' });
    } catch(err) {
        setStatus('❌ ' + err.message, '#f87171');
        addLog('❌ ' + err.message, '#f87171');
        setDot('stopped'); btnStart.disabled = false;
    }
});

btnPause.addEventListener('click',  () => sendCommand(isPaused ? 'resume' : 'pause'));
btnStop.addEventListener('click',   () => sendCommand('stop'));

btnReinject.addEventListener('click', async () => {
    showRefreshBanner(false);
    addLog('🔄 Reinjecting after page refresh...', '#38bdf8');
    setStatus('Reinjecting...', '#38bdf8');
    try {
        const tab = await getSnTab();
        if (!tab) { setStatus('❌ No SN tab found!', '#f87171'); return; }
        activeTabId = tab.id;
        await chrome.tabs.sendMessage(activeTabId, { source: 'DISPATCHER_INJECT' });
    } catch(err) {
        setStatus('❌ Reinject failed: ' + err.message, '#f87171');
        addLog('❌ ' + err.message, '#f87171');
    }
});

btnExport.addEventListener('click', () => {
    if (allLogs.length === 0) { setStatus('No logs to export yet.', '#fbbf24'); return; }
    const lines  = allLogs.map(l => '[' + l.time + '] ' + l.msg);
    const header = "Aryan's Dispatcher — Activity Log Export\nExported: " +
        new Date().toLocaleString() + '\n' + '='.repeat(50) + '\n';
    const blob = new Blob([header + lines.join('\n')], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'dispatcher-log-' + new Date().toISOString().slice(0,19).replace(/:/g,'-') + '.txt';
    a.click(); URL.revokeObjectURL(url);
    addLog('📥 Logs exported (' + allLogs.length + ' entries)', '#a78bfa');
});

// ── Pin overlay ───────────────────────────────────────────────────────────────
async function injectOverlay(tab) {
    // Inject as a file (not `func`) into the MAIN world. The overlay's own
    // OVERLAY_CMD messages are dispatched via content.js's injectIntoPage(),
    // which runs in the page's MAIN world — the overlay's listener must live
    // in that same world to reliably receive them.
    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        files: ['overlay.js']
    });
}


btnPin.addEventListener('click', async () => {
    try {
        const tab = await getSnTab();
        if (!tab) { setStatus('❌ No ServiceNow tab to pin on!', '#f87171'); return; }
        if (!activeTabId) activeTabId = tab.id;
        await injectOverlay(tab);
        for (const l of allLogs) {
            await chrome.tabs.sendMessage(activeTabId, {
                source: 'DISPATCHER_POPUP', command: '__overlay__',
                data: { action: 'addLog', time: l.time, msg: l.msg, color: l.color }
            }, { frameId: 0 }).catch(() => {});
        }
        addLog('📌 Overlay pinned to page', '#a78bfa');
        setStatus('Overlay active on SN page', '#a78bfa');
    } catch(err) {
        setStatus('❌ Pin failed: ' + err.message, '#f87171');
        addLog('❌ Pin error: ' + err.message, '#f87171');
    }
});

// ── Init — runs every time popup opens ───────────────────────────────────────
(async () => {
    const tab = await getSnTab();
    if (!tab) {
        connBadge.textContent = '● No SN Tab';
        connBadge.style.color = '#f87171';
        setStatus('Open ServiceNow first, then click Start', '#f87171');
        return;
    }

    connBadge.textContent = '● SN Tab Found';
    connBadge.style.color = '#4ade80';
    activeTabId = tab.id;

    const state = await loadState();

    if (!state.isRunning) return; // Never started, nothing to restore

    // Storage says it was running — ping the page to see if script survived
    setStatus('Checking...', '#64748b');
    const alive = await pingPage(tab.id);

    if (alive) {
        // Script is still running (popup was just closed and reopened)
        isRunning = true; isPaused = !!state.isPaused;
        applyRunningUI();
        if (isPaused) {
            setDot('paused'); setStatus('⏸ Paused — reopened popup', '#fbbf24');
        } else {
            setStatus('⚡ Running — reopened popup', '#4ade80');
        }
        if (state.lastInc !== undefined) statInc.textContent = state.lastInc;
        if (state.lastChg !== undefined) statChg.textContent = state.lastChg;
        addLog('🔄 Reconnected to running dispatcher', '#38bdf8');
    } else {
        // Script is dead — page was refreshed
        isRunning = true; // Keep true so reinject works
        applyStoppedUI();
        btnPause.disabled = true; btnStop.disabled = true; // Can't pause/stop dead script
        showRefreshBanner(true);
        setStatus('⚠️ Page was refreshed — click Reinject', '#fbbf24');
        addLog('⚠️ Page refreshed — script stopped. Click Reinject.', '#fbbf24');
        if (state.lastInc !== undefined) statInc.textContent = state.lastInc;
        if (state.lastChg !== undefined) statChg.textContent = state.lastChg;
    }
})();
