(function() {
    if (document.getElementById('sn-dispatcher-overlay')) return;
    const style = document.createElement('style');
    style.id = 'sn-dispatcher-overlay-style';
    style.textContent = `
        #sn-dispatcher-overlay { position:fixed;bottom:24px;right:24px;width:260px;background:#0d1117;border:1px solid #1f2937;border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,0.6);z-index:2147483647;font-family:'Nunito','Segoe UI',sans-serif;font-size:12px;color:#e2e8f0;overflow:hidden;resize:both;min-width:220px;min-height:180px; }
        #sn-overlay-header { background:linear-gradient(135deg,#0d1f3c,#0a1628);padding:10px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #1f2937;cursor:grab;user-select:none; }
        #sn-overlay-header:active { cursor:grabbing; }
        #sn-overlay-title { font-weight:900;font-size:12px;color:#fff; }
        #sn-overlay-title span { color:#38bdf8; }
        #sn-overlay-dot { width:10px;height:10px;border-radius:50%;background:#64748b;transition:background 0.3s;flex-shrink:0; }
        #sn-overlay-dot.running { background:#4ade80;box-shadow:0 0 6px rgba(74,222,128,0.6); }
        #sn-overlay-dot.paused  { background:#fbbf24; }
        #sn-overlay-dot.stopped { background:#64748b; }
        #sn-overlay-close { background:none;border:none;color:#64748b;font-size:16px;cursor:pointer;padding:0 2px;line-height:1; }
        #sn-overlay-close:hover { color:#f87171; }
        #sn-overlay-body { padding:10px 12px; }
        #sn-overlay-timer { text-align:center;font-size:28px;font-weight:900;color:#38bdf8;letter-spacing:-1px;margin-bottom:6px;transition:color 0.3s; }
        #sn-overlay-timer.urgent { color:#fbbf24; }
        #sn-overlay-progress-wrap { height:3px;background:#1f2937;border-radius:3px;overflow:hidden;margin-bottom:8px; }
        #sn-overlay-progress { height:100%;background:linear-gradient(90deg,#0070d2,#38bdf8);border-radius:3px;width:0%;transition:width 1s linear; }
        #sn-overlay-stats { display:flex;gap:6px;margin-bottom:8px; }
        .sn-overlay-stat { flex:1;background:#161b22;border:1px solid #1f2937;border-radius:8px;padding:6px 8px;text-align:center; }
        .sn-overlay-stat-label { font-size:8px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px; }
        .sn-overlay-stat-value { font-size:18px;font-weight:900;color:#e2e8f0;line-height:1.2; }
        .sn-overlay-stat-value.green { color:#4ade80; }
        .sn-overlay-stat-value.blue  { color:#38bdf8; }
        #sn-overlay-log-label { font-size:8px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;border-top:1px solid #1f2937;padding-top:8px; }
        #sn-overlay-log { max-height:120px;overflow-y:auto;font-size:10px;line-height:1.7;scrollbar-width:thin;scrollbar-color:#1f2937 transparent;word-break:break-word; }
        .sn-ov-line { display:flex;gap:5px;align-items:flex-start; }
        .sn-ov-time { color:#64748b;flex-shrink:0;font-size:9px;padding-top:1px; }
        .sn-ov-msg  { color:#e2e8f0; }
    `;
    document.head.appendChild(style);
    const el = document.createElement('div');
    el.id = 'sn-dispatcher-overlay';
    el.innerHTML = `
        <div id="sn-overlay-header">
            <div style="display:flex;align-items:center;gap:8px">
                <div id="sn-overlay-dot" class="running"></div>
                <span id="sn-overlay-title">Aryan's <span>Dispatcher</span></span>
            </div>
            <button id="sn-overlay-close">✕</button>
        </div>
        <div id="sn-overlay-body">
            <div id="sn-overlay-timer">—</div>
            <div id="sn-overlay-progress-wrap"><div id="sn-overlay-progress"></div></div>
            <div id="sn-overlay-stats">
                <div class="sn-overlay-stat"><div class="sn-overlay-stat-label">INC Routed</div><div class="sn-overlay-stat-value green" id="sn-ov-inc">—</div></div>
                <div class="sn-overlay-stat"><div class="sn-overlay-stat-label">CHG Routed</div><div class="sn-overlay-stat-value blue" id="sn-ov-chg">—</div></div>
            </div>
            <div id="sn-overlay-log-label">Live Log</div>
            <div id="sn-overlay-log"><div class="sn-ov-line"><span class="sn-ov-msg" style="color:#475569">No activity yet...</span></div></div>
        </div>
    `;
    document.body.appendChild(el);
    document.getElementById('sn-overlay-close').addEventListener('click', () => {
        el.remove(); const s=document.getElementById('sn-dispatcher-overlay-style'); if(s)s.remove();
    });
    const hdr=document.getElementById('sn-overlay-header');
    let dragging=false,startX,startY,origTop,origLeft;
    hdr.addEventListener('mousedown',e=>{
        dragging=true;const r=el.getBoundingClientRect();
        origLeft=r.left;origTop=r.top;startX=e.clientX;startY=e.clientY;
        el.style.right='auto';el.style.bottom='auto';el.style.left=origLeft+'px';el.style.top=origTop+'px';
        e.preventDefault();
    });
    document.addEventListener('mousemove',e=>{if(!dragging)return;el.style.left=(origLeft+e.clientX-startX)+'px';el.style.top=(origTop+e.clientY-startY)+'px';});
    document.addEventListener('mouseup',()=>{dragging=false;});
    window.addEventListener('message',function(ev){
        if(!ev.data||ev.data.type!=='OVERLAY_CMD')return;
        const d=ev.data;
        if(d.action==='addLog'){
            const logEl=document.getElementById('sn-overlay-log');if(!logEl)return;
            const ph=logEl.querySelector('.sn-ov-msg[style*="475569"]');if(ph)ph.parentElement.remove();
            const line=document.createElement('div');line.className='sn-ov-line';
            const t=document.createElement('span');t.className='sn-ov-time';t.textContent=d.time;
            const m=document.createElement('span');m.className='sn-ov-msg';m.style.color=d.color;m.textContent=d.msg;
            line.appendChild(t);line.appendChild(m);logEl.appendChild(line);
            logEl.scrollTop=logEl.scrollHeight;
            while(logEl.children.length>50)logEl.removeChild(logEl.firstChild);
        }
        if(d.action==='setCountdown'){
            const t=document.getElementById('sn-overlay-timer');const p=document.getElementById('sn-overlay-progress');if(!t)return;
            t.textContent=d.value;const parts=d.value.split(':');
            if(parts.length===2){const rem=parseInt(parts[0])*60+parseInt(parts[1]);if(p)p.style.width=((120-rem)/120*100)+'%';t.classList.toggle('urgent',rem<=15);}
        }
        if(d.action==='setState'){const dot=document.getElementById('sn-overlay-dot');if(dot)dot.className=d.state;}
        if(d.action==='updateStats'){
            const i=document.getElementById('sn-ov-inc');const c=document.getElementById('sn-ov-chg');
            if(i)i.textContent=d.inc;if(c)c.textContent=d.chg;
        }
    });
})();
