'use strict';

// ── Background Service Worker ─────────────────────────────────────────────────
// Two code paths:
//
//   1. FROM POPUP  → msg.source = 'SN_COMMANDS_EXEC_TAB'
//      Popup knows the tabId; background just calls executeScript.
//
//   2. FROM CONTENT SCRIPT  → msg.source = 'SN_COMMANDS_EXEC'
//      Content script doesn't know its own tabId; we get it from sender.tab.id.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Path 1: popup already resolved the tab
    if (msg && msg.source === 'SN_COMMANDS_EXEC_TAB') {
        const { tabId, frameId, script } = msg;
        chrome.scripting.executeScript({
            target: { tabId, frameIds: [frameId != null ? frameId : 0] },
            world:  'MAIN',
            func:   (code) => { (0, eval)(code); },
            args:   [script]
        }).then(() => sendResponse({ ok: true }))
          .catch(err => {
              console.error('[SN Commands] executeScript error:', err);
              sendResponse({ ok: false, error: err.message });
          });
        return true;
    }

    // Path 2: content script (palette) triggered the run — sender has tabId
    if (msg && msg.source === 'SN_COMMANDS_EXEC') {
        const tabId   = sender.tab && sender.tab.id;
        const frameId = sender.frameId || 0;
        const { script } = msg;

        if (!tabId) {
            sendResponse({ ok: false, error: 'No sender tabId' });
            return false;
        }

        chrome.scripting.executeScript({
            target: { tabId, frameIds: [frameId] },
            world:  'MAIN',
            func:   (code) => { (0, eval)(code); },
            args:   [script]
        }).then(() => sendResponse({ ok: true }))
          .catch(err => {
              console.error('[SN Commands] executeScript error:', err);
              sendResponse({ ok: false, error: err.message });
          });
        return true;
    }

    return false;
});
